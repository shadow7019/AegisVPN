AegisVPN for Windows — real WireGuard engine + one-click public relays
=======================================================================

RUN
  Double-click "AegisVPN.exe" (accept the admin prompt — the VPN tunnel
  needs the Wintun adapter). Your browser opens the dashboard at
  http://127.0.0.1:8080

FEATURES
  * FREE PUBLIC RELAYS — the "Public relays" tab connects to the free
    VPNGate community network with one click: live reachability checks,
    fastest relay auto-pick, profile fetched and connected automatically.
  * 80 private WireGuard nodes in 56 countries (bundled registry)
  * Kill Switch, Threat Protection DNS, Obfuscation, Double VPN
  * Dashboard + API bind to 127.0.0.1 only

CLI
  cli\aegisvpn.exe relays list --country US
  cli\aegisvpn.exe relays connect --country JP
  cli\aegisvpn.exe connect -node <id> | status | disconnect

wintun.dll is the WireGuard-project's Wintun driver interface (wintun.net).
