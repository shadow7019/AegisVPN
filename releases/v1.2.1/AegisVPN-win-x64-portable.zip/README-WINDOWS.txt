AegisVPN 1.1.0 for Windows (portable)
=====================================

WHAT'S INSIDE
  AegisVPN.exe          desktop app (connect, server picker, Kill Switch,
                        Double VPN, Threat Protection, Split Tunneling)
  aegisvpn.exe          engine CLI + control daemon (real WireGuard Go engine)
  nodes.json            bundled registry: 80 WireGuard nodes / 56 countries
  install-service.ps1   run the engine as a Windows service (auto-start)
  uninstall-service.ps1 remove the service

QUICK START
  1. Extract this folder anywhere (e.g. C:\AegisVPN).
  2. Run AegisVPN.exe. It starts the engine daemon automatically.
  3. Pick a country, hit Connect. That's it.

  CLI alternative (run as Administrator for the tunnel interface):
      aegisvpn.exe nodes
      aegisvpn.exe connect --node us-newyork-2 --killswitch --threat
      aegisvpn.exe status
      aegisvpn.exe disconnect

IF WINDOWS SHOWS "Windows protected your PC" (SmartScreen)
  AegisVPN binaries are NOT code-signed with a paid certificate, so
  SmartScreen shows this warning on first run:
    1. Click "More info".
    2. Click "Run anyway".
  You only need to do this once. Verify downloads against SHA256SUMS.txt.

IF THE APP SAYS "WebView2 runtime not found"
  The UI uses Microsoft's WebView2 runtime (preinstalled on Windows 10
  21H2+ and Windows 11). If it is missing, install the Evergreen runtime:
  https://developer.microsoft.com/microsoft-edge/webview2/

FIREWALL / ADMIN RIGHTS
  Creating the WireGuard tunnel (WinTun adapter) requires Administrator.
  Run AegisVPN.exe or aegisvpn.exe from an elevated prompt the first time,
  or use install-service.ps1 to run the engine as the SYSTEM service —
  then the desktop app talks to it without elevation prompts.

VERIFY YOUR DOWNLOAD (PowerShell)
  Get-FileHash AegisVPN-Setup-x64.exe -Algorithm SHA256
  Compare with SHA256SUMS.txt from the release page.
