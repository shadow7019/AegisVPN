AegisVPN for macOS — real WireGuard-protocol VPN
================================================

INSTALL
  1. Drag "AegisVPN.app" onto "Applications" in the Finder sidebar.
     If the ""AegisVPN" Not Opened — Apple could not verify ..." dialog
     appears (one Done button), click Done and go to step 2.
  2. FIRST LAUNCH PASS (30 seconds, one time only) — that dialog is the
     standard Gatekeeper screen for apps without Apple notarization; the
     code signature itself is valid. Any ONE of these clears it:
       • Terminal (Spotlight -> "Terminal"), paste + Return:
           xattr -dr com.apple.quarantine /Applications/AegisVPN.app
       • System Settings -> Privacy & Security -> scroll to
         "Open Anyway" next to AegisVPN -> Open Anyway -> Open.
       • macOS 13/14: right-click the app -> Open -> Open.
     Gatekeeper never asks again after this.
  3. Launch AegisVPN — it asks for administrator rights ONCE (the VPN
     tunnel needs a utun device) and opens the dashboard in your browser
     at http://127.0.0.1:8080

FEATURES
  * 80 WireGuard nodes in 56 countries (bundled registry, live updates)
  * Kill Switch, Threat Protection (DNS filtering), Obfuscation
  * Double VPN (two-hop chains), P2P / Onion / dedicated node types
  * Split tunneling, Meshnet, Dark Web Monitor, auto-connect
  * Dashboard + API bind to 127.0.0.1 only — nothing leaves your machine

WHY IS THE APP ONLY ~15 MB?
  AegisVPN is a native Go engine — the same wireguard-go core behind
  NordLynx — with the dashboard and the 80-node fleet registry built in.
  It does NOT bundle a browser runtime: Electron-based apps ship a full
  Chromium copy, which is why those installers are 150-200 MB. Small is
  correct here: unpacked, AegisVPN.app is ~33 MB.

IF THE APP STILL WILL NOT OPEN
  Run the engine directly from Terminal so failures print real output:
      /Applications/AegisVPN.app/Contents/MacOS/AegisVPN
  A healthy start ends with:
      aegisvpn dashboard on http://127.0.0.1:8080
  and your browser opens the dashboard automatically.

CLI
  /Applications/AegisVPN.app/Contents/MacOS/cli/aegisvpn-darwin-$(uname -m)
  commands: connect | disconnect | status | nodes | daemon | version

Logs:  /var/root/Library/Logs/AegisVPN-server.log (elevated run)
       ~/Library/Logs/                            (fallback run)
